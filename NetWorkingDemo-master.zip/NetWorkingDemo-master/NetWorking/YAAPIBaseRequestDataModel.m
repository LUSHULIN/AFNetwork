//
//  YAAPIBaseRequestDataModel.m
//  NetWorking
//
//  Created by Yasin on 16/4/27.
//  Copyright © 2016年 Yasin. All rights reserved.
//

#import "YAAPIBaseRequestDataModel.h"

@implementation YAAPIBaseRequestDataModel

@end
