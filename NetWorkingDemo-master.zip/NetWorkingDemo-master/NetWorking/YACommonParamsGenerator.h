//
//  YACommonParamsGenerator.h
//  NetWorking
//
//  Created by Yasin on 16/4/27.
//  Copyright © 2016年 Yasin. All rights reserved.
//
/**
 *  应用基本信息生成字典
 */
#import <Foundation/Foundation.h>

@interface YACommonParamsGenerator : NSObject
+ (NSDictionary *)commonParamsDictionary;
@end
