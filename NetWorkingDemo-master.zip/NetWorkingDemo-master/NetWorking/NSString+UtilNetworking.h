//
//  NSString+UtilNetworking.h
//  NetWorking
//
//  Created by Yasin on 16/4/27.
//  Copyright © 2016年 Yasin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (UtilNetworking)
+ (BOOL)isEmptyString:(NSString *)string;
@end
