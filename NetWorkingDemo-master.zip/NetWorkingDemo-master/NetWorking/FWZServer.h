//
//  FWZServer.h
//  NetWorking
//
//  Created by Yasin on 16/4/27.
//  Copyright © 2016年 Yasin. All rights reserved.
//

#import "YABaseServers.h"

@interface FWZServer : YABaseServers<YABaseServiceProtocol>

@end
