//
//  UIDevice+UtilNetworking.h
//  NetWorking
//
//  Created by Yasin on 16/4/27.
//  Copyright © 2016年 Yasin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDevice (UtilNetworking)
- (NSString *)platform;
-(NSString *)correspondVersion;
@end
